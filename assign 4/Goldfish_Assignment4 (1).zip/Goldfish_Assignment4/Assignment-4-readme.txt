Assignment 4:
Program Files Included:
* InputGeneration.ipynb
* x.py
* y.py
* Computing Xors for round.ipynb
* Finding Round 6 Keys.ipynb
* Final_key_and_all_roundkey.ipynb
* des.cpp
How to run ?
1. First run InputGeneration on notebook.
2. Then run x.py(This uses pexpect library so run on linux environment).
3. Then run y.py(This uses pexpect library so run on linux environment).
4. Then run Computing Xors for round.ipynb.
5. Then run Finding Round 6 Keys.ipynb.
6. Final_key_and_all_roundkey.ipynb.
7. Run des.cpp to get final key answer remove .

