This was an assignment on to crack a simple hashing based protocol to decrypt password.

How to run ?
*unzip all files
*run "make"